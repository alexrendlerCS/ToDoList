package csc335.ToDoList;
/*
 * This class uses a listView to display each item in a 
 * toDo list from top (highest priority) to bottom (lowest
 * priority). It has buttons to add a new toDO item, move 
 * the selected toDo item to the top/bottom, move the selected
 * toDo item up/down in priority and a button to remove the
 * toDo item. The class keeps the function of first toDo class
 * where the user can open open with an empty list or load
 * the old one, along with the ability to close without saving
 * or overwrite the already existing ser file.
 * Author: Alex Rendler
 */
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class ToDoListGUI extends Application {

    ListView<String> listView = new ListView<String>();
    ObservableList<String> items = FXCollections.observableArrayList();
    
    /*
     *  Sets the scene and closing alerts. And action handlers
     *  for the buttons. Also determines whether or not to save
     *  the changes to the ser file if prompted.
     */
    @Override
    public void start(Stage stage) {
        getSavedToDosOrNot();
        listView.setItems(items);

        Button addButton = new Button("Add");
        addButton.setOnAction(event -> addNewItem());

        Button moveTopButton = new Button("Move To Top");
        moveTopButton.setOnAction(event -> moveSelectedToDoToTop());

        Button moveBottomButton = new Button("Move To Bottom");
        moveBottomButton.setOnAction(event -> moveSelectedToDoToEnd());

        Button moveUpButton = new Button("Move Up");
        moveUpButton.setOnAction(event -> raiseSelectedToDoPriority());

        Button moveDownButton = new Button("Move Down");
        moveDownButton.setOnAction(event -> lowerSelectedToDoPriority());

        Button removeButton = new Button("Remove");
        removeButton.setOnAction(event -> removeSelectedToDo());

        HBox buttonBox = new HBox(addButton, moveTopButton, moveBottomButton, moveUpButton, moveDownButton, removeButton);
        buttonBox.setSpacing(10);
        buttonBox.setPadding(new Insets(10));

        BorderPane root = new BorderPane();
        root.setCenter(listView);
        root.setBottom(buttonBox);

        var scene = new Scene(root, 800, 400);
        stage.setScene(scene);
        stage.setOnCloseRequest(event -> {
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirm Save");
            alert.setHeaderText("Do you want to save changes to the ToDo list?");
            alert.setContentText("Click OK to overwrite the serialized file with your changes");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                ToDoListOne.save(new ArrayList<>(items));
                System.out.println("Serialized data saved.");
            } else {
                System.out.println("Serialized data not saved.");
            }
        });

        stage.show();
    }

    
    public static void main(String[] args) {
        launch();
    }

    // Determines whether or not to load in ser
    // file content.
    @SuppressWarnings("unchecked")
    private void getSavedToDosOrNot() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setHeaderText("Click cancel to start with an empty list");
        alert.setContentText("Click OK to read from a .ser file");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            String fileName = "TODOs.ser";
            try {
                FileInputStream bytesFromDisk = new FileInputStream(fileName);
                ObjectInputStream inFile = new ObjectInputStream(bytesFromDisk);
                List<String> list = (List<String>) inFile.readObject();
                items.addAll(list);
                System.out.println("Read from serialized data file");
                inFile.close();
                bytesFromDisk.close();
            } catch (IOException ioe) {
                System.out.println("Reading objects failed");
            } catch (ClassNotFoundException cnfe) {
                System.out.println("Class not found");
            }
        } else {
            System.out.println("Create an empty list");
        }
    }
    
    // Adds a new toDo item at index 0 when add button clicked.
    private void addNewItem() {
        TextInputDialog dialog = new TextInputDialog("");
        dialog.setTitle("New ToDo");
        dialog.setHeaderText("Add a new ToDo item:");
        dialog.setContentText("Enter the task:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(task -> {
            items.add(0, task); // add new item to the top of the list
            listView.getSelectionModel().select(0); // select the new item
        });
    }
    
    // Moves the selected toDo item to index 0 when clicked
    private void moveSelectedToDoToTop() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex > 0) {
            String item = items.remove(selectedIndex);
            items.add(0, item);
            listView.getSelectionModel().select(0);
        }
    }
   
    // Moves the selected toDo item to the last index when clicked
    private void moveSelectedToDoToEnd() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < items.size() - 1) {
            String item = items.remove(selectedIndex);
            items.add(item);
            listView.getSelectionModel().select(items.size() - 1);
        }
    }
    
    // Moves the selected toDo item up one index when clicked
    private void raiseSelectedToDoPriority() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex > 0) {
            String item = items.remove(selectedIndex);
            items.add(selectedIndex - 1, item);
            listView.getSelectionModel().select(selectedIndex - 1);
        }
    }
    
    // Moves the selected toDo item down one index when clicked
    private void lowerSelectedToDoPriority() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex < items.size() - 1) {
            String item = items.remove(selectedIndex);
            items.add(selectedIndex + 1, item);
            listView.getSelectionModel().select(selectedIndex + 1);
        }
    }

    // Removes the selected toDo item when clicked
    private void removeSelectedToDo() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            items.remove(selectedIndex);
        }
    }
}
