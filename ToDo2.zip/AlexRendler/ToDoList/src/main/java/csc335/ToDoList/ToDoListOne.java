package csc335.ToDoList;

/*
 * This class sets up the ser file so that it contains a list of 
 * 3 strings to start. It also contains a save method which saves
 * the changes from the user if prompted to the ser file.
 * Author: Alex Rendler
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


class AnyClass implements Serializable {
}

	// Saves the given list from the textField into the ser file
	public class ToDoListOne{
		@SuppressWarnings("unchecked")
	    public static void save(List<String> list) {
	        String fileName = "TODOs.ser";
	
	        try {
	            FileOutputStream bytesToDisk = new FileOutputStream(fileName);
	            ObjectOutputStream outFile = new ObjectOutputStream(bytesToDisk);
	            outFile.writeObject(list);
	            outFile.close();
	            bytesToDisk.close();
	            System.out.println("Serialized data saved");
	        } catch (IOException ioe) {
	            System.out.println("Writing objects failed");
	        }
	    }
		
	// Writes the original three string into the list in the ser file
	@SuppressWarnings("unchecked")
	public static List<String> main(String[] args) {
		String fileName = "TODOs.ser";
		ArrayList<String> list = new ArrayList<String>();
		list.add("Snowboard");
		list.add("Homework");
		list.add("Sleep");
		try {
			FileOutputStream bytesToDisk = new FileOutputStream(fileName);
			ObjectOutputStream outFile = new ObjectOutputStream(bytesToDisk);
			outFile.writeObject(list);
			outFile.close();
		}catch(IOException ioe) {
			System.out.println("Writing objects failed");
		}
		
		FileInputStream rawBytes;
		try {
			rawBytes = new FileInputStream(fileName);
			ObjectInputStream inFile = new ObjectInputStream(rawBytes);
			List<String> first = (ArrayList<String>)inFile.readObject();
			inFile.close();
			System.out.println(first);
			return first;
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return list;
	}

}



	