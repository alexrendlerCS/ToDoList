module csc335.ToDoList {
    requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
    exports csc335.ToDoList;
}
